﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Deployment.Application;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace BAMAnalysisKit
{
    public partial class GenericBAMAnalysis : Form
    {
        string filename = "";
        string mb = "2048";
        public GenericBAMAnalysis()
        {
            InitializeComponent();
        }

        private void GenericBAMAnalysis_Load(object sender, EventArgs e)
        {                       
            timer1.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(openFileDialog1.ShowDialog(this)==DialogResult.OK)
            {
                filename = openFileDialog1.FileName;
                textBox1.Text = Path.GetFileName(filename);
                button2.Enabled = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(textBox1.Text=="")
            {
                MessageBox.Show("You must select the input file", "BAM Analysis Kit", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            if(!chr1.Checked && !chr2.Checked && !chr3.Checked && !chr4.Checked && !chr5.Checked && 
                !chr6.Checked && !chr7.Checked && !chr8.Checked && !chr9.Checked && !chr10.Checked && 
                !chr11.Checked && !chr12.Checked && !chr13.Checked && !chr14.Checked && !chr15.Checked && 
                !chr16.Checked && !chr17.Checked && !chr18.Checked && !chr19.Checked && !chr20.Checked && 
                !chr21.Checked && !chr22.Checked && !chrX.Checked && !chrY.Checked && !chrM.Checked )
            {
                MessageBox.Show("You must select atleast one chromosome!","BAM Analysis Kit",MessageBoxButtons.OK,MessageBoxIcon.Stop);
                return;
            }


            StringBuilder sb = new StringBuilder("#\r\n# BAM Analysis Kit Configuration File\r\n# NOTE: Do not edit unless you know what you are doing\r\n#\r\n# These parameters define what to process\r\n#\r\n");
            for (int i = 1; i <= 22; i++)
            {
                CheckBox c = this.Controls["groupBox1"].Controls["chr" + i.ToString()] as CheckBox;
                if(c.Checked)                
                    sb.Append("CHR_" + i + "=yes\r\n");
                else
                    sb.Append("CHR_" + i + "=no\r\n");
            }

            if(chrX.Checked)
                sb.Append("CHR_X=yes\r\n");
            else
                sb.Append("CHR_X=no\r\n");

            if (chrY.Checked)
                sb.Append("CHR_Y=yes\r\n");
            else
                sb.Append("CHR_Y=no\r\n");

            if (chrM.Checked)
                sb.Append("CHR_M=yes\r\n");
            else
                sb.Append("CHR_M=no\r\n");

            if (chkYstr.Checked)
                sb.Append("YSTR=yes\r\n");
            else
                sb.Append("YSTR=no\r\n");

            if (chkTelomere.Checked)
                sb.Append("TELOMERE=yes\r\n");
            else
                sb.Append("TELOMERE=no\r\n");

            if (cbAdmixture.Checked)
                sb.Append("ADMIXTURE=yes\r\n");
            else
                sb.Append("ADMIXTURE=no\r\n");

            if (cbSNPedia.Checked)
                sb.Append("SNPEDIA=yes\r\n");
            else
                sb.Append("SNPEDIA=no\r\n");

            sb.Append("#\r\n# Execution Configuration\r\n");

            sb.Append("BAMKIT_JVM=" + jvm.Text+"\r\n");
            sb.Append("BAMKIT_THREADS=" + threads.Text + "\r\n");

            if (cbDelVCF.Checked)
                sb.Append("DEL_VCF=yes\r\n");
            else
                sb.Append("DEL_VCF=no\r\n");

            if(MessageBox.Show("The processing will use most of your computer resources and may fom a few minutes to several hours, or even days, depending on your BAM file and your computer processing power. If you wish to continue, please click 'Yes'. Otherwise, click 'No'.","Confirmation",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.No)
            {
                return;
            }

            File.WriteAllText("bamkit.config", sb.ToString());
            File.WriteAllText("generic_bam.bat", BAMAnalysisKit.Properties.Resources.console_bam);

            ProcessStartInfo stinfo = new ProcessStartInfo();
            stinfo.FileName = "generic_bam.bat";
            stinfo.Arguments = "\"" + Path.GetFullPath(filename)+"\"";
            stinfo.CreateNoWindow = false;
            stinfo.UseShellExecute = true;
            stinfo.WindowStyle = ProcessWindowStyle.Maximized;
            Process.Start(stinfo);
            Application.Exit();
        }


        private void populateBamkitConfig()
        {
            if (File.Exists("bamkit.config"))
            {
                string[] lines = File.ReadAllLines("bamkit.config");
                foreach (string line in lines)
                {
                    if (line.StartsWith("#"))
                        continue;
                    string[] data = line.Split(new char[] { '=' });

                    for (int i = 1; i <= 22; i++)
                    {
                        CheckBox c = this.Controls["groupBox1"].Controls["chr" + i.ToString()] as CheckBox;
                        if (data[0] == "CHR_" + i)
                        {
                            if (data[1] == "yes")
                                c.Checked = true;
                            else
                                c.Checked = false;
                        }
                    }

                    if (data[0] == "CHR_X")
                    {
                        if(data[1] == "yes")
                            chrX.Checked = true;
                        else
                            chrX.Checked = false;
                    }

                    if (data[0] == "CHR_Y")
                    {
                        if (data[1] == "yes")
                            chrY.Checked = true;
                        else
                            chrY.Checked = false;
                    }

                    if (data[0] == "CHR_M")
                    {
                        if (data[1] == "yes")
                            chrM.Checked = true;
                        else
                            chrM.Checked = false;
                    }

                    if (data[0] == "TELOMERE")
                    {
                        if (data[1] == "yes")
                            chkTelomere.Checked = true;
                        else
                            chkTelomere.Checked = false;
                    }

                    if (data[0] == "YSTR")
                    {
                        if (data[1] == "yes")
                            chkYstr.Checked = true;
                        else
                            chkYstr.Checked = false;
                    }

                    if (data[0] == "ADMIXTURE")
                    {
                        if (data[1] == "yes")
                            cbAdmixture.Checked = true;
                        else
                            cbAdmixture.Checked = false;
                    }


                    if (data[0] == "BAMKIT_JVM")
                        jvm.Text = data[1];
                    else
                        jvm.Text = "-Xmx2g";

                    if (data[0] == "BAMKIT_THREADS")
                        threads.Text = data[1];
                    else
                        threads.Text = "-Xmx2g";


                    if (data[0] == "DEL_VCF")
                    {
                        if (data[1] == "yes")
                            cbDelVCF.Checked = true;
                        else
                            cbDelVCF.Checked = false;
                    }

                    if (data[0] == "SNPEDIA")
                    {
                        if (data[1] == "yes")
                            cbSNPedia.Checked = true;
                        else
                            cbSNPedia.Checked = false;
                    }
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            //
            if (!(Directory.Exists("ref") && Directory.Exists("bin")))
            {
                MessageBox.Show("This executable cannot be executed independently from BAM Analysis Kit. Please execute from the BAM Analysis Kit home folder and try again.", "BAM Analysis Kit", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            } 

            populateBamkitConfig(); 


            this.Text = Application.ProductName + " v2.09";
            if (chkMemory.Checked)
            {
                try
                {
                    PerformanceCounter ramCounter = new PerformanceCounter("Memory", "Available MBytes");
                    mb = ramCounter.NextValue().ToString();
                }
                catch (Exception)
                {
                    MessageBox.Show("Unable to detect RAM. Using default as 2 GB.","Warning",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    mb = "2048";
                }
            }
            else
                mb = "2048";
            
            if (int.Parse(mb) > 1536)
            {
                if (!Environment.Is64BitOperatingSystem)
                {
                    if (MessageBox.Show("You are not running this program on a 64-bit machine. You can proceed at your own risk. Do you want to continue?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        button1.Enabled = true;
                    }     
                    else
                    {
                        Application.Exit();
                    }
                }
                else
                {
                    button1.Enabled = true;
                }
            }
            else
            {
                if(MessageBox.Show("Your Windows OS don't have enough memory. Do you want to continue with available memory?","Warning",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)==DialogResult.Yes)
                {
                    button1.Enabled = true;
                }
                else
                {
                    Application.Exit();
                }
            }

            jvm.Text = "-Xmx" + mb + "m";
            threads.Text = Environment.ProcessorCount.ToString();
        }

        private void btnSelectAll_Click(object sender, EventArgs e)
        {
            chr1.Checked = true;
            chr2.Checked = true;
            chr3.Checked = true;
            chr4.Checked = true;
            chr5.Checked = true;
            chr6.Checked = true;
            chr7.Checked = true;
            chr8.Checked = true;
            chr9.Checked = true;
            chr10.Checked = true;
            chr11.Checked = true;
            chr12.Checked = true;
            chr13.Checked = true;
            chr14.Checked = true;
            chr15.Checked = true;
            chr16.Checked = true;
            chr17.Checked = true;
            chr18.Checked = true;
            chr19.Checked = true;
            chr20.Checked = true;
            chr21.Checked = true;
            chr22.Checked = true;
            chrX.Checked = true;
            chrY.Checked = true;
            chrM.Checked = true;
        }

        private void btnClearAll_Click(object sender, EventArgs e)
        {
            chr1.Checked = false;
            chr2.Checked = false;
            chr3.Checked = false;
            chr4.Checked = false;
            chr5.Checked = false;
            chr6.Checked = false;
            chr7.Checked = false;
            chr8.Checked = false;
            chr9.Checked = false;
            chr10.Checked = false;
            chr11.Checked = false;
            chr12.Checked = false;
            chr13.Checked = false;
            chr14.Checked = false;
            chr15.Checked = false;
            chr16.Checked = false;
            chr17.Checked = false;
            chr18.Checked = false;
            chr19.Checked = false;
            chr20.Checked = false;
            chr21.Checked = false;
            chr22.Checked = false;
            chrX.Checked = false;
            chrY.Checked = false;
            chrM.Checked = false;
        }


        private void button3_Click(object sender, EventArgs e)
        {

            MessageBox.Show("BAM Analysis Kit v2.093" + "\r\n\r\nWebsite: y-str.org\r\nDeveloper: Felix Immanuel <i@fi.id.au>\r\nLicense: MIT License\r\n\t\nTools Used: SAMTools, picard, bamtools, lobSTR, telseq, Cygwin, GATK, Java", "About", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public string CurrentVersion
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetName().Version.Major.ToString() + "." + Assembly.GetExecutingAssembly().GetName().Version.Minor.ToString();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("\r\nRuntime Memory - The program tries to allocate maximum of available memory for Java heap. If not able to allocate or unchecked, 2 GB will be allocated.\r\n\r\nSelect Chromosomes - Select the chromosomes you wish to analyse. You must select atleast one for this program to proceed.\r\n\r\nMiscellaneous - Select Telomere, Y-STR.", "Help", MessageBoxButtons.OK);
        }

        private void chkMemory_CheckedChanged(object sender, EventArgs e)
        {
            if(chkMemory.Checked)
                jvm.Text = "-Xmx" + mb + "m";
            else
                jvm.Text = "-Xmx2g";
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("www.y-str.org/2014/04/bam-analysis-kit.html");
        }    
    }
}
