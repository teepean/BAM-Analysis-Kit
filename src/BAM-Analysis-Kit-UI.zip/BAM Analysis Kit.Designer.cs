﻿namespace BAMAnalysisKit
{
    partial class GenericBAMAnalysis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GenericBAMAnalysis));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbDelVCF = new System.Windows.Forms.CheckBox();
            this.threads = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.jvm = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cbAdmixture = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.chkMemory = new System.Windows.Forms.CheckBox();
            this.chkYstr = new System.Windows.Forms.CheckBox();
            this.chkTelomere = new System.Windows.Forms.CheckBox();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.btnSelectAll = new System.Windows.Forms.Button();
            this.chr22 = new System.Windows.Forms.CheckBox();
            this.chrX = new System.Windows.Forms.CheckBox();
            this.chrY = new System.Windows.Forms.CheckBox();
            this.chrM = new System.Windows.Forms.CheckBox();
            this.chr21 = new System.Windows.Forms.CheckBox();
            this.chr17 = new System.Windows.Forms.CheckBox();
            this.chr18 = new System.Windows.Forms.CheckBox();
            this.chr19 = new System.Windows.Forms.CheckBox();
            this.chr20 = new System.Windows.Forms.CheckBox();
            this.chr16 = new System.Windows.Forms.CheckBox();
            this.chr12 = new System.Windows.Forms.CheckBox();
            this.chr13 = new System.Windows.Forms.CheckBox();
            this.chr14 = new System.Windows.Forms.CheckBox();
            this.chr15 = new System.Windows.Forms.CheckBox();
            this.chr11 = new System.Windows.Forms.CheckBox();
            this.chr7 = new System.Windows.Forms.CheckBox();
            this.chr8 = new System.Windows.Forms.CheckBox();
            this.chr9 = new System.Windows.Forms.CheckBox();
            this.chr10 = new System.Windows.Forms.CheckBox();
            this.chr6 = new System.Windows.Forms.CheckBox();
            this.chr2 = new System.Windows.Forms.CheckBox();
            this.chr3 = new System.Windows.Forms.CheckBox();
            this.chr4 = new System.Windows.Forms.CheckBox();
            this.chr5 = new System.Windows.Forms.CheckBox();
            this.chr1 = new System.Windows.Forms.CheckBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.cbSNPedia = new System.Windows.Forms.CheckBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(490, 68);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(162, 49);
            this.button1.TabIndex = 0;
            this.button1.Text = "Browse";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(490, 418);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(162, 51);
            this.button2.TabIndex = 1;
            this.button2.Text = "Start Analysis >>";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "BAM Files|*.bam";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(119, 17);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(533, 23);
            this.textBox1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 21);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 19);
            this.label1.TabIndex = 3;
            this.label1.Text = "BAM File: ";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbSNPedia);
            this.groupBox1.Controls.Add(this.cbDelVCF);
            this.groupBox1.Controls.Add(this.threads);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.jvm);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.cbAdmixture);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.chkMemory);
            this.groupBox1.Controls.Add(this.chkYstr);
            this.groupBox1.Controls.Add(this.chkTelomere);
            this.groupBox1.Controls.Add(this.btnClearAll);
            this.groupBox1.Controls.Add(this.btnSelectAll);
            this.groupBox1.Controls.Add(this.chr22);
            this.groupBox1.Controls.Add(this.chrX);
            this.groupBox1.Controls.Add(this.chrY);
            this.groupBox1.Controls.Add(this.chrM);
            this.groupBox1.Controls.Add(this.chr21);
            this.groupBox1.Controls.Add(this.chr17);
            this.groupBox1.Controls.Add(this.chr18);
            this.groupBox1.Controls.Add(this.chr19);
            this.groupBox1.Controls.Add(this.chr20);
            this.groupBox1.Controls.Add(this.chr16);
            this.groupBox1.Controls.Add(this.chr12);
            this.groupBox1.Controls.Add(this.chr13);
            this.groupBox1.Controls.Add(this.chr14);
            this.groupBox1.Controls.Add(this.chr15);
            this.groupBox1.Controls.Add(this.chr11);
            this.groupBox1.Controls.Add(this.chr7);
            this.groupBox1.Controls.Add(this.chr8);
            this.groupBox1.Controls.Add(this.chr9);
            this.groupBox1.Controls.Add(this.chr10);
            this.groupBox1.Controls.Add(this.chr6);
            this.groupBox1.Controls.Add(this.chr2);
            this.groupBox1.Controls.Add(this.chr3);
            this.groupBox1.Controls.Add(this.chr4);
            this.groupBox1.Controls.Add(this.chr5);
            this.groupBox1.Controls.Add(this.chr1);
            this.groupBox1.Location = new System.Drawing.Point(19, 57);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Size = new System.Drawing.Size(458, 465);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Advanced Options";
            // 
            // cbDelVCF
            // 
            this.cbDelVCF.AutoSize = true;
            this.cbDelVCF.Location = new System.Drawing.Point(45, 401);
            this.cbDelVCF.Name = "cbDelVCF";
            this.cbDelVCF.Size = new System.Drawing.Size(175, 19);
            this.cbDelVCF.TabIndex = 42;
            this.cbDelVCF.Text = "Delete VCF after processing";
            this.cbDelVCF.UseVisualStyleBackColor = true;
            // 
            // threads
            // 
            this.threads.Location = new System.Drawing.Point(311, 358);
            this.threads.Name = "threads";
            this.threads.Size = new System.Drawing.Size(50, 23);
            this.threads.TabIndex = 41;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(245, 361);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 15);
            this.label7.TabIndex = 40;
            this.label7.Text = "Threads";
            // 
            // jvm
            // 
            this.jvm.Location = new System.Drawing.Point(311, 324);
            this.jvm.Name = "jvm";
            this.jvm.Size = new System.Drawing.Size(106, 23);
            this.jvm.TabIndex = 39;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(245, 327);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 15);
            this.label6.TabIndex = 38;
            this.label6.Text = "JVM Heap";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(242, 295);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 15);
            this.label5.TabIndex = 37;
            this.label5.Text = "Execution Options";
            // 
            // cbAdmixture
            // 
            this.cbAdmixture.AutoSize = true;
            this.cbAdmixture.Location = new System.Drawing.Point(45, 376);
            this.cbAdmixture.Name = "cbAdmixture";
            this.cbAdmixture.Size = new System.Drawing.Size(137, 19);
            this.cbAdmixture.TabIndex = 36;
            this.cbAdmixture.Text = "Calculate Admixture";
            this.cbAdmixture.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(42, 30);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 15);
            this.label4.TabIndex = 35;
            this.label4.Text = "Runtime Memory";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(42, 295);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 15);
            this.label3.TabIndex = 34;
            this.label3.Text = "Miscellaneous";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(42, 90);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 15);
            this.label2.TabIndex = 33;
            this.label2.Text = "Select Chromosomes";
            // 
            // chkMemory
            // 
            this.chkMemory.AutoSize = true;
            this.chkMemory.Checked = true;
            this.chkMemory.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkMemory.Location = new System.Drawing.Point(59, 57);
            this.chkMemory.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chkMemory.Name = "chkMemory";
            this.chkMemory.Size = new System.Drawing.Size(304, 19);
            this.chkMemory.TabIndex = 32;
            this.chkMemory.Text = "Use maximum available memory to Java Processes";
            this.chkMemory.UseVisualStyleBackColor = true;
            this.chkMemory.CheckedChanged += new System.EventHandler(this.chkMemory_CheckedChanged);
            // 
            // chkYstr
            // 
            this.chkYstr.AutoSize = true;
            this.chkYstr.Location = new System.Drawing.Point(45, 351);
            this.chkYstr.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chkYstr.Name = "chkYstr";
            this.chkYstr.Size = new System.Drawing.Size(109, 19);
            this.chkYstr.TabIndex = 31;
            this.chkYstr.Text = "Calculate Y-STR";
            this.chkYstr.UseVisualStyleBackColor = true;
            // 
            // chkTelomere
            // 
            this.chkTelomere.AutoSize = true;
            this.chkTelomere.Location = new System.Drawing.Point(45, 326);
            this.chkTelomere.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chkTelomere.Name = "chkTelomere";
            this.chkTelomere.Size = new System.Drawing.Size(168, 19);
            this.chkTelomere.TabIndex = 31;
            this.chkTelomere.Text = "Calculate Telomere Length";
            this.chkTelomere.UseVisualStyleBackColor = true;
            // 
            // btnClearAll
            // 
            this.btnClearAll.Location = new System.Drawing.Point(141, 249);
            this.btnClearAll.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(88, 27);
            this.btnClearAll.TabIndex = 29;
            this.btnClearAll.Text = "Clear All";
            this.btnClearAll.UseVisualStyleBackColor = true;
            this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
            // 
            // btnSelectAll
            // 
            this.btnSelectAll.Location = new System.Drawing.Point(45, 249);
            this.btnSelectAll.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnSelectAll.Name = "btnSelectAll";
            this.btnSelectAll.Size = new System.Drawing.Size(88, 27);
            this.btnSelectAll.TabIndex = 28;
            this.btnSelectAll.Text = "Select All";
            this.btnSelectAll.UseVisualStyleBackColor = true;
            this.btnSelectAll.Click += new System.EventHandler(this.btnSelectAll_Click);
            // 
            // chr22
            // 
            this.chr22.AutoSize = true;
            this.chr22.Location = new System.Drawing.Point(109, 223);
            this.chr22.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr22.Name = "chr22";
            this.chr22.Size = new System.Drawing.Size(40, 19);
            this.chr22.TabIndex = 27;
            this.chr22.Text = "22";
            this.chr22.UseVisualStyleBackColor = true;
            // 
            // chrX
            // 
            this.chrX.AutoSize = true;
            this.chrX.Location = new System.Drawing.Point(161, 223);
            this.chrX.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chrX.Name = "chrX";
            this.chrX.Size = new System.Drawing.Size(33, 19);
            this.chrX.TabIndex = 26;
            this.chrX.Text = "X";
            this.chrX.UseVisualStyleBackColor = true;
            // 
            // chrY
            // 
            this.chrY.AutoSize = true;
            this.chrY.Location = new System.Drawing.Point(213, 223);
            this.chrY.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chrY.Name = "chrY";
            this.chrY.Size = new System.Drawing.Size(32, 19);
            this.chrY.TabIndex = 25;
            this.chrY.Text = "Y";
            this.chrY.UseVisualStyleBackColor = true;
            // 
            // chrM
            // 
            this.chrM.AutoSize = true;
            this.chrM.Location = new System.Drawing.Point(263, 223);
            this.chrM.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chrM.Name = "chrM";
            this.chrM.Size = new System.Drawing.Size(37, 19);
            this.chrM.TabIndex = 24;
            this.chrM.Text = "M";
            this.chrM.UseVisualStyleBackColor = true;
            // 
            // chr21
            // 
            this.chr21.AutoSize = true;
            this.chr21.Location = new System.Drawing.Point(59, 223);
            this.chr21.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr21.Name = "chr21";
            this.chr21.Size = new System.Drawing.Size(40, 19);
            this.chr21.TabIndex = 23;
            this.chr21.Text = "21";
            this.chr21.UseVisualStyleBackColor = true;
            // 
            // chr17
            // 
            this.chr17.AutoSize = true;
            this.chr17.Location = new System.Drawing.Point(109, 196);
            this.chr17.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr17.Name = "chr17";
            this.chr17.Size = new System.Drawing.Size(40, 19);
            this.chr17.TabIndex = 22;
            this.chr17.Text = "17";
            this.chr17.UseVisualStyleBackColor = true;
            // 
            // chr18
            // 
            this.chr18.AutoSize = true;
            this.chr18.Location = new System.Drawing.Point(161, 196);
            this.chr18.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr18.Name = "chr18";
            this.chr18.Size = new System.Drawing.Size(40, 19);
            this.chr18.TabIndex = 21;
            this.chr18.Text = "18";
            this.chr18.UseVisualStyleBackColor = true;
            // 
            // chr19
            // 
            this.chr19.AutoSize = true;
            this.chr19.Location = new System.Drawing.Point(213, 196);
            this.chr19.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr19.Name = "chr19";
            this.chr19.Size = new System.Drawing.Size(40, 19);
            this.chr19.TabIndex = 20;
            this.chr19.Text = "19";
            this.chr19.UseVisualStyleBackColor = true;
            // 
            // chr20
            // 
            this.chr20.AutoSize = true;
            this.chr20.Location = new System.Drawing.Point(263, 196);
            this.chr20.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr20.Name = "chr20";
            this.chr20.Size = new System.Drawing.Size(40, 19);
            this.chr20.TabIndex = 19;
            this.chr20.Text = "20";
            this.chr20.UseVisualStyleBackColor = true;
            // 
            // chr16
            // 
            this.chr16.AutoSize = true;
            this.chr16.Location = new System.Drawing.Point(59, 196);
            this.chr16.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr16.Name = "chr16";
            this.chr16.Size = new System.Drawing.Size(40, 19);
            this.chr16.TabIndex = 18;
            this.chr16.Text = "16";
            this.chr16.UseVisualStyleBackColor = true;
            // 
            // chr12
            // 
            this.chr12.AutoSize = true;
            this.chr12.Location = new System.Drawing.Point(109, 170);
            this.chr12.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr12.Name = "chr12";
            this.chr12.Size = new System.Drawing.Size(40, 19);
            this.chr12.TabIndex = 17;
            this.chr12.Text = "12";
            this.chr12.UseVisualStyleBackColor = true;
            // 
            // chr13
            // 
            this.chr13.AutoSize = true;
            this.chr13.Location = new System.Drawing.Point(161, 170);
            this.chr13.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr13.Name = "chr13";
            this.chr13.Size = new System.Drawing.Size(40, 19);
            this.chr13.TabIndex = 16;
            this.chr13.Text = "13";
            this.chr13.UseVisualStyleBackColor = true;
            // 
            // chr14
            // 
            this.chr14.AutoSize = true;
            this.chr14.Location = new System.Drawing.Point(213, 170);
            this.chr14.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr14.Name = "chr14";
            this.chr14.Size = new System.Drawing.Size(40, 19);
            this.chr14.TabIndex = 15;
            this.chr14.Text = "14";
            this.chr14.UseVisualStyleBackColor = true;
            // 
            // chr15
            // 
            this.chr15.AutoSize = true;
            this.chr15.Location = new System.Drawing.Point(263, 170);
            this.chr15.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr15.Name = "chr15";
            this.chr15.Size = new System.Drawing.Size(40, 19);
            this.chr15.TabIndex = 14;
            this.chr15.Text = "15";
            this.chr15.UseVisualStyleBackColor = true;
            // 
            // chr11
            // 
            this.chr11.AutoSize = true;
            this.chr11.Location = new System.Drawing.Point(59, 170);
            this.chr11.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr11.Name = "chr11";
            this.chr11.Size = new System.Drawing.Size(40, 19);
            this.chr11.TabIndex = 13;
            this.chr11.Text = "11";
            this.chr11.UseVisualStyleBackColor = true;
            // 
            // chr7
            // 
            this.chr7.AutoSize = true;
            this.chr7.Location = new System.Drawing.Point(109, 143);
            this.chr7.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr7.Name = "chr7";
            this.chr7.Size = new System.Drawing.Size(33, 19);
            this.chr7.TabIndex = 12;
            this.chr7.Text = "7";
            this.chr7.UseVisualStyleBackColor = true;
            // 
            // chr8
            // 
            this.chr8.AutoSize = true;
            this.chr8.Location = new System.Drawing.Point(161, 143);
            this.chr8.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr8.Name = "chr8";
            this.chr8.Size = new System.Drawing.Size(33, 19);
            this.chr8.TabIndex = 11;
            this.chr8.Text = "8";
            this.chr8.UseVisualStyleBackColor = true;
            // 
            // chr9
            // 
            this.chr9.AutoSize = true;
            this.chr9.Location = new System.Drawing.Point(213, 143);
            this.chr9.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr9.Name = "chr9";
            this.chr9.Size = new System.Drawing.Size(33, 19);
            this.chr9.TabIndex = 10;
            this.chr9.Text = "9";
            this.chr9.UseVisualStyleBackColor = true;
            // 
            // chr10
            // 
            this.chr10.AutoSize = true;
            this.chr10.Location = new System.Drawing.Point(263, 143);
            this.chr10.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr10.Name = "chr10";
            this.chr10.Size = new System.Drawing.Size(40, 19);
            this.chr10.TabIndex = 9;
            this.chr10.Text = "10";
            this.chr10.UseVisualStyleBackColor = true;
            // 
            // chr6
            // 
            this.chr6.AutoSize = true;
            this.chr6.Location = new System.Drawing.Point(59, 143);
            this.chr6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr6.Name = "chr6";
            this.chr6.Size = new System.Drawing.Size(33, 19);
            this.chr6.TabIndex = 8;
            this.chr6.Text = "6";
            this.chr6.UseVisualStyleBackColor = true;
            // 
            // chr2
            // 
            this.chr2.AutoSize = true;
            this.chr2.Location = new System.Drawing.Point(109, 117);
            this.chr2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr2.Name = "chr2";
            this.chr2.Size = new System.Drawing.Size(33, 19);
            this.chr2.TabIndex = 7;
            this.chr2.Text = "2";
            this.chr2.UseVisualStyleBackColor = true;
            // 
            // chr3
            // 
            this.chr3.AutoSize = true;
            this.chr3.Location = new System.Drawing.Point(161, 117);
            this.chr3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr3.Name = "chr3";
            this.chr3.Size = new System.Drawing.Size(33, 19);
            this.chr3.TabIndex = 6;
            this.chr3.Text = "3";
            this.chr3.UseVisualStyleBackColor = true;
            // 
            // chr4
            // 
            this.chr4.AutoSize = true;
            this.chr4.Location = new System.Drawing.Point(213, 117);
            this.chr4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr4.Name = "chr4";
            this.chr4.Size = new System.Drawing.Size(33, 19);
            this.chr4.TabIndex = 5;
            this.chr4.Text = "4";
            this.chr4.UseVisualStyleBackColor = true;
            // 
            // chr5
            // 
            this.chr5.AutoSize = true;
            this.chr5.Location = new System.Drawing.Point(263, 117);
            this.chr5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr5.Name = "chr5";
            this.chr5.Size = new System.Drawing.Size(33, 19);
            this.chr5.TabIndex = 4;
            this.chr5.Text = "5";
            this.chr5.UseVisualStyleBackColor = true;
            // 
            // chr1
            // 
            this.chr1.AutoSize = true;
            this.chr1.Location = new System.Drawing.Point(59, 117);
            this.chr1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chr1.Name = "chr1";
            this.chr1.Size = new System.Drawing.Size(33, 19);
            this.chr1.TabIndex = 0;
            this.chr1.Text = "1";
            this.chr1.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(576, 147);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(76, 35);
            this.button3.TabIndex = 5;
            this.button3.Text = "About";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(490, 147);
            this.button4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(78, 35);
            this.button4.TabIndex = 6;
            this.button4.Text = "Help";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // cbSNPedia
            // 
            this.cbSNPedia.AutoSize = true;
            this.cbSNPedia.Location = new System.Drawing.Point(45, 427);
            this.cbSNPedia.Name = "cbSNPedia";
            this.cbSNPedia.Size = new System.Drawing.Size(162, 19);
            this.cbSNPedia.TabIndex = 43;
            this.cbSNPedia.Text = "Generate SNPedia Report";
            this.cbSNPedia.UseVisualStyleBackColor = true;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel1.LinkColor = System.Drawing.Color.Gray;
            this.linkLabel1.Location = new System.Drawing.Point(588, 521);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(52, 15);
            this.linkLabel1.TabIndex = 7;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "y-str.org";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // GenericBAMAnalysis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(665, 545);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "GenericBAMAnalysis";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BAM Analysis Kit";
            this.Load += new System.EventHandler(this.GenericBAMAnalysis_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chr22;
        private System.Windows.Forms.CheckBox chrX;
        private System.Windows.Forms.CheckBox chrY;
        private System.Windows.Forms.CheckBox chrM;
        private System.Windows.Forms.CheckBox chr21;
        private System.Windows.Forms.CheckBox chr17;
        private System.Windows.Forms.CheckBox chr18;
        private System.Windows.Forms.CheckBox chr19;
        private System.Windows.Forms.CheckBox chr20;
        private System.Windows.Forms.CheckBox chr16;
        private System.Windows.Forms.CheckBox chr12;
        private System.Windows.Forms.CheckBox chr13;
        private System.Windows.Forms.CheckBox chr14;
        private System.Windows.Forms.CheckBox chr15;
        private System.Windows.Forms.CheckBox chr11;
        private System.Windows.Forms.CheckBox chr7;
        private System.Windows.Forms.CheckBox chr8;
        private System.Windows.Forms.CheckBox chr9;
        private System.Windows.Forms.CheckBox chr10;
        private System.Windows.Forms.CheckBox chr6;
        private System.Windows.Forms.CheckBox chr2;
        private System.Windows.Forms.CheckBox chr3;
        private System.Windows.Forms.CheckBox chr4;
        private System.Windows.Forms.CheckBox chr5;
        private System.Windows.Forms.CheckBox chr1;
        private System.Windows.Forms.Button btnClearAll;
        private System.Windows.Forms.Button btnSelectAll;
        private System.Windows.Forms.CheckBox chkTelomere;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox chkMemory;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.CheckBox chkYstr;
        private System.Windows.Forms.CheckBox cbAdmixture;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox jvm;
        private System.Windows.Forms.TextBox threads;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox cbDelVCF;
        private System.Windows.Forms.CheckBox cbSNPedia;
        private System.Windows.Forms.LinkLabel linkLabel1;

    }
}

