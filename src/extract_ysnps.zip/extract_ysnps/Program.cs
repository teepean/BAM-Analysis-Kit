﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace extract_ysnps
{
    class Program
    {
        static void Main(string[] args)
        {
/*
    10000133	1	G	Z15137
    10000350	1	T	Z5341
    10000477	1	T	Z4880
    10000888	1	A	Z17019
*/
            if(args.Length!=2 || !Directory.Exists("ref"))
            {
                Console.WriteLine(" ** not to be executed independently. it is designed to work specifically with BAM analysis kit (y-str.org). no documentation is available ** ");
                Console.WriteLine(@"bin\bamkit\extract_ysnps.exe ref\ysnp_hg19.ref chrY.tmp");
                return;
            }
            string yref = args[0];
            string ytmp = args[1];
            string outfile = @"out\Complete_SNPs_y.csv";
            string ysnpfile = @"out\Y_SNPs.txt";

            if(!File.Exists(yref))
            {
                Console.WriteLine("WARNING: "+yref + " - File doesn't exit");
                return;
            }

            if (!File.Exists(ytmp))
            {
                Console.WriteLine("WARNING: " + ytmp + " - File doesn't exit");
                return;
            }

            string[] lines = File.ReadAllLines(yref);
            long pos = -1;
            string alleles = "";
            string snp = "";
            StringBuilder sb = new StringBuilder("SNP Name,Position,Derived,Reference,Genotype\r\n");
            StringBuilder ysb = new StringBuilder();

            Dictionary<long, string[]>[] ysnp_map = new Dictionary<long, string[]>[10];

            for (int i = 0; i < 10; i++)
                ysnp_map[i] = new Dictionary<long, string[]>();

            foreach (string line in lines)
            {
                string[] data = line.Split(new char[] { '\t' });
                pos = long.Parse(data[0]);
                alleles = data[2];
                snp = data[3];
                for (int i = 0; i < 10;i++ )
                    if (!ysnp_map[i].ContainsKey(pos))
                    {
                        ysnp_map[i].Add(pos, new string[] { alleles, snp });
                        break;
                    }
            }

            var mlines = File.ReadLines(ytmp);
            long mpos = -1;
            string ref_ances = "";
            string usr_alleles = "";
            string ysnp = "";
            string derivied = "";

            bool snp_search = false;
            string partial_allele = "";            
            int counter = -1;


            foreach (string line in mlines)
            {
                string[] data = line.Split(new char[] { '\t' });
                mpos = long.Parse(data[0]);
                ref_ances = data[1];
                usr_alleles = data[2];
                for (int i = 0; i < 10; i++)
                {
                    if (snp_search)
                    {

                        if (ysnp_map[i].ContainsKey(mpos - counter))
                        {
                            // part of the snp
                            counter++;
                            string[] data2 = ysnp_map[i][mpos];
                            ysnp = data2[1];
                            derivied = data2[0];
                            partial_allele = partial_allele + usr_alleles;
                            if (derivied.StartsWith(partial_allele))
                            {
                                if (derivied.Length == partial_allele.Length)
                                {
                                    if (partial_allele == derivied)
                                    {
                                        sb.Append(ysnp + "," + (mpos - counter).ToString() + ",Yes(+)," + ref_ances + "," + partial_allele + "\r\n");
                                        ysb.Append(ysnp + "+ ");
                                    }
                                    else
                                    {
                                        sb.Append(ysnp + "," + (mpos - counter).ToString() + ",No(-)," + ref_ances + "," + usr_alleles + "\r\n");
                                        ysb.Append(ysnp + "- ");
                                    }
                                    snp_search = false;
                                    counter = 0;
                                    partial_allele = "";
                                }
                                else
                                {
                                    counter++;
                                    continue;
                                }
                            }
                            else
                            {
                                snp_search = false;
                                counter = 0;
                                partial_allele = "";
                            }
                        }
                        else
                        {
                            snp_search = false;
                            counter = 0;
                            partial_allele = "";
                        }
                    }

                    if (ysnp_map[i].ContainsKey(mpos))
                    {
                        // present...
                        string[] data2 = ysnp_map[i][mpos];
                        ysnp = data2[1];
                        derivied = data2[0];
                        //PF7599,2668940,No(-),A,A
                        if (usr_alleles.Length == 1)
                        {
                            if (usr_alleles == derivied)
                            {
                                sb.Append(ysnp + "," + mpos.ToString() + ",Yes(+)," + ref_ances + "," + usr_alleles + "\r\n");
                                ysb.Append(ysnp + "+ ");
                            }
                            else
                            {
                                sb.Append(ysnp + "," + mpos.ToString() + ",No(-)," + ref_ances + "," + usr_alleles + "\r\n");
                                ysb.Append(ysnp + "- ");
                            }
                            snp_search = false;
                        }
                        else if (usr_alleles.Length > 1)
                        {
                            counter = 1;
                            snp_search = true;
                            partial_allele = usr_alleles;
                        }
                    }
                }
            }
            File.WriteAllText(outfile, sb.ToString());
            File.WriteAllText(ysnpfile, ysb.ToString().Trim().Replace(" ",", "));
        }
    }
}
