﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;

namespace mtdna_hg
{
    class Program
    {
        static void Main(string[] args)
        {
            //
            if(args.Length!=1)
            {
                Console.WriteLine("** this executable is used internally by bam analysis kit. use it independently at your own risk ***");
                Console.WriteLine(@"bin\bamkit\mtdna_hg.exe out\RSRS_mtDNA.txt");
                return;
            }

            if(!File.Exists(args[0]))
            {
                Console.WriteLine("WARNING:"+args[0]+" - File doesn't exist");
                return;
            }            

            string markers = File.ReadAllText(args[0]).Trim();

            if(markers.Trim()=="")
            {
                Console.WriteLine("WARNING: No markers found");
                return;
            }

            try
            {
                XDocument doc = XDocument.Parse(mtdna_hg.Properties.Resources.mtDNAPhylogeny);

                TreeNode root = new TreeNode("Eve");
                //treeView1.Nodes.Add(root);
                MtDnaHg mtclass = new MtDnaHg();
                foreach (XElement el in doc.Root.Elements())
                {
                    mtclass.buildTree(root, el);
                }
                //root.Expand();

                string hg = mtclass.doProcessing(markers);
                File.WriteAllText(@"out\MtDNA_Haplogroup.txt", hg);
                mtclass.saveReport(@"out\MtDNA_Haplogroup_Report.html");
            }
            catch (Exception e1)
            {
                Console.WriteLine("ERROR: " + e1.Message);                
            }           
        }
    }
}
