﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace admixure_report
{
    class Program
    {
        /*
         
         @DATA@


         */
         
        static void Main(string[] args)
        {
            if(args.Length!=4)
            {
                Console.WriteLine("*** This tool is designed to be used along with BAM Analysis kit, not independently. Use it at your own risk ***");
                Console.WriteLine("bin\\bamkit\\admixure_report.exe <input-admix-out-file> <name> <title> <output-html-file>");
                return;
            }

            string input_file=args[0];

            if (!File.Exists(input_file))
            {
                Console.WriteLine("ERROR: Input file does not exist!");
                return;
            }



            try
            {
                string[] line = File.ReadAllLines(input_file);
                string name=args[1];
                string title = args[2];
                string outfile = args[3];

                string[] data=Regex.Replace(line[0].Trim(),"[\\s]{1,}"," ").Split(new char[]{' '});
            
                string[] labels=new string[data.Length-2];
                for(int i=2;i<data.Length;i++)
                    labels[i-2]=data[i];
            
                data=Regex.Replace(line[1].Trim(),"[\\s]{1,}"," ").Split(new char[]{' '});
            
                string[] values=new string[data.Length-2];
                for(int i=2;i<data.Length;i++)
                    values[i-2]=data[i];

                if(labels.Length!=values.Length) // something wrong
                    return;

                File.WriteAllText(outfile, generateHtml(name, title, labels, values));
            }
            catch (Exception e1)
            {
                Console.WriteLine("ERROR: " + e1.Message);
            }
        }


        static string generateHtml(string name, string title, string[] label, string[] value)
        {
            string _js_1 = "var "+name+" = new CanvasJS.Chart(\"" + name + "Container\",\r\n {\r\n title:{\r\n text: \"" + title + "\"\r\n },\r\n legend: {\r\n maxWidth: 650,\r\n itemWidth: 300\r\n },\r\n data: [\r\n {\r\n type: \"pie\",\r\n showInLegend: true,\r\n legendText: \"{indexLabel}\",\r\n dataPoints: [";
            string _js_2 = "]}]});" + name + ".render();";

            StringBuilder _data = new StringBuilder();
            for(int i=0;i<label.Length;i++)
            {
                _data.Append("{ y: " + value[i] + ", indexLabel: \"" + label[i] + "\" },");
            }

            string front_js=_js_1+_data.ToString().Substring(0,_data.ToString().Length-1)+_js_2;

            	//{ y: 4181563, indexLabel: "PlayStation 3" },
				//{ y: 2175498, indexLabel: "Wii" },

            string html = admixure_report.Properties.Resources.admixture;
            html = html.Replace("@JS@", front_js);

            string data = "<div id=\"" + name + "Container\" style=\"height: 600px; width: 100%;\"></div><br><br>";

            html = html.Replace("@DATA@", data);

            return html;
        }
    }
}
