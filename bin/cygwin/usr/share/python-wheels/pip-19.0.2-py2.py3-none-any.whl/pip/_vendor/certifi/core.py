#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
certifi.py
~~~~~~~~~~

This module returns the installation location of cacert.pem.
"""
import os


def where():
    return '/etc/pki/tls/certs/ca-bundle.crt'


if __name__ == '__main__':
    print(where())
